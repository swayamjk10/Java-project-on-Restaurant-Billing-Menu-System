/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk_project;

/**
 *
 * @author USer
 */
public class Addition {
    
    public double spdosa;
    public double samosa;
    public double burger;
    public double pizza;
    
    public double mojito;
    public double chocomilkshake;
    public double icetea;
    public double cappuccino;
    
    public double foodprice;
    public double drinkprice;
    public double totalprice;
    
    
    public double Totalprice(){
        
        foodprice = spdosa+samosa+burger+pizza;
        drinkprice = mojito+chocomilkshake+icetea+cappuccino;
        
        return foodprice+drinkprice;       
        
    }   
    
    public double cspdosa=60;
    public double csamosa=15;
    public double cburger=30;
    public double cpizza=100;
    
    public double cmojito=65;
    public double cchocomilkshake=40;
    public double cicetea=25;
    public double ccappuccino=90;
    
}

    

